# importamos las bibliotecas necesarias
import math
import rclpy
from rclpy.node import Node
from custom_interface.srv import MyMoveMsg

# definimos la clase cliente


class ClientAsync(Node):

    def __init__(self):
        #inicializa el nodo cliente
        super().__init__('movement_client')
        #crea el objeto cliente
        self.client = self.create_client(MyMoveMsg, 'movement')
        #cada segundo revisa si el servicio esta activo
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('el servicio no esta activo, prueba de nuevo...')
        
        #crea el mensaje 
        self.req = MyMoveMsg.Request()

    def send_request(self):
        # crea una lista de coordenadas que representan la trayectoria circular
        radius = 1.0  # radio de la circunferencia
        step_size = 10  # tamaño de paso (en grados)
        coordinates = []
        for theta in range(0, 360, step_size):
            x = radius * math.cos(math.radians(theta))
            y = radius * math.sin(math.radians(theta))
            coordinates.append((x, y))
        # convierte la lista de coordenadas en una cadena separada por comas y la añade al 
        self.req.move = ','.join([f'{x:.2f},{y:.2f}' for x, y in coordinates])
        # envía la petición del servicio
        self.future = self.client.call_async(self.req)
        
        
def main(args=None):
    rclpy.init(args=args)
    client = ClientAsync()
    client.send_request()
    while rclpy.ok():
        rclpy.spin_once(client)
        if client.future.done():
            try:
                response = client.future.result()
            except Exception as e:
                client.get_logger().info('La llamada al servicio ha fallado %r' % (e,))
            else:
                client.get_logger().info('Respuesta del servicio %r' % (response.success,))
            break
    client.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

